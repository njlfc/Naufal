<?php
include "top.php"; 
include "dbx.php";
include "tabel.php";
$tab=3;
include "tab.php"; 

$qry = "SELECT * FROM posts  where Status='Draft' ";
$data = $db->query($qry);
$n=0;
$maxchar=100;
?> 

</br>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
            <table class="table table-bordered" id="csstab1">
                <tr>
                <th>#</th>  
                <th>Title</th>
                <th>Content</th>
                <th>Category</th>
                <th>Status</th>  
                <th>Action</th>    
                </tr> 
                <?php  while ($row = $data->fetch_assoc()) {  
                    $n=$n+1; 
                    $shortcontent = strlen($row["Content"]) > $maxchar ? substr($row["Content"], 0, $maxchar) . "..." : $row["Content"];?> 
                <tr>
                <td><?php echo $n; ?></td>
                <td><?php echo $row["Title"]; ?></td>
                <td><?php echo $shortcontent; ?></td>
                <td><?php echo $row["Category"]; ?></td>
                <td><?php echo $row["Status"]; ?></td>
                <td><a href="edit.php?id=<?php echo $row["Id"];?>"><i class="fa fa-pencil" style="margin-left: 5px;" aria-hidden="true"></i></a>
                <a href="trash_action.php?id=<?php echo $row["Id"];?>&met=draft"><i class="fa fa-trash" style="margin-left: 5px; color: red;" aria-hidden="true" onclick="return confirm('Move to trash?')"></i></a>
                </td>
                 </tr>
                        <?php   }; ?> 
                </table>
            </div>
        </div>
    </div>