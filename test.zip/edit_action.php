<?php
include "top.php"; 
include "dbx.php";
include "tabel.php";


if ( $_POST['add'] == 'Publish'){
    $stat='Published';
    $url = "url=published.php";
}else {
    $stat='Draft';
    $url = "url=drafts.php";
}

$qry ="UPDATE posts SET Title='".$_POST['title']."',Content='".$_POST['content']."',Category='".$_POST['category']."',Status='".$stat."' where Id='".$_POST['id']."' " ;
//die($qry);
mysqli_query($db, $qry);
?>
<meta http-equiv="refresh" content="1; <?php echo $url; ?> ">


<center>
	<h2>LOADING.........</h2>
</center>
