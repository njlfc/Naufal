<?php
include "top.php"; 
include "dbx.php";
include "tabel.php";
$tab=6;
include "tab.php";

?>

</style>
<form method="post" name="frm" action="add_action.php">
  
  <div class="container">
        <div class="row">
        
            <div class="col-md-2 col-md-offset-1">
    
  <table class="table table-bordered" id="csstab1">

    <tbody> 
  <tr>
    <td valign="top" size="20" ><strong> Title</strong></td>
    <td><input type="text" name="title" size="50" placeholder="Article Title"  value=""/></td>
  </tr>
  
  <tr>
  <td ><strong>Content</strong></td>
    <td>
    <textarea input type="text" cols="100px" rows="2" name="content" placeholder="Article Content" value=""></textarea >
    </td>
    </tr>
  <tr>
    <td   ><strong>Category</strong></td>
    <td ><input type="text" name="category" size="50" placeholder="Article Category" value="" /></td>
  </tr>

 
    <td colspan="2"><input type="submit" name="add" class="btn bg-success" value="Publish"></input> <input type="submit" name="add" class="btn bg-info" value="Draft"></input></td>
  </tr>
  </tbody>  
</table>
</div>
</div>
</div>
</form>