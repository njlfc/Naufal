-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2023 at 06:57 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `article`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `Id` int(11) NOT NULL,
  `Title` varchar(200) DEFAULT NULL,
  `Content` text DEFAULT NULL,
  `Category` varchar(100) DEFAULT NULL,
  `Status` varchar(100) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`Id`, `Title`, `Content`, `Category`, `Status`, `created_date`, `updated_date`) VALUES
(1, 'Roman Monarchy', 'The most accepted date for the foundation of Rome is 753 BC. The first form of government in Rome was monarchical according to the archaeological findings and the legends. In the excavations carried out in the Roman Forum, in the Regia, which was the former royal residence, a glass of bucchero was founding dating from the seventh century with the inscription Rex (king). The word regei was also found on the Lapis Niger, an ancient shrine in the Roman Forum. An inscription found beneath the black marble is considered to be a law.\r\n\r\nIt is also possible to make out when Rome was a kingdom thanks to other institutions in the Lazio region. For example, the rex Nemorensis (king of the forest), a priest of the goddess Diana who looked after the forests from the sixth century BC until the Roman Empire.\r\n\r\nCurioulsy, the Romans would maintain the same institutions throughout the centuries, transforming the roles of those in charge to suit the period. In this case, during the Roman Republic, the figure of the rex sacrorum (king of the sacred) substituted the king figure, but was only given religious functions. \r\n\r\nRomulus, son of the god of war and the daughter of the king Numitor, was the first king of Rome and also its founder, thus the city was called after him. He formed the Roman Senate with one hundred men and gave the inhabitants of Rome a body of laws.', 'History', 'Published', '2023-08-26 08:38:09', '2023-08-26 23:41:05'),
(3, 'Rome The Capital of Italy', 'The unification process of Italy started in 1848 and ended with the creation of the Kingdom of Italy in 1861. Since Rome was under the control of the Papacy, Florence was made temporary capital of Italy. In 1870, Italian troops entered Rome, ending more than one thousand years of Papal control over the city. However, the Pope did not accept the unification of the peninsula and took refuge in the Vatican until the 11 February, 1929, when the Lateran Treaty was signed by Mussolini and the Pope Pius XI, creating the Vatican state.\r\n\r\nMussolini and the National Fascist Party, allies of Nazi Germany, marched in Rome in 1922 and came to power in the country, declaring a new Italian Empire. During the following years many monuments, buildings and streets were restored and Rome became the administrative capital, increasing the population of Rome, from 212.000 inhabitants to over one million. (During the Roman Empire, Rome had over 2 million inhabitants).', 'History', 'Published', '2023-08-26 08:39:19', '2023-08-26 23:42:10'),
(4, 'The First Human', 'First things first: A “human” is anyone who belongs to the genus Homo (Latin for “man”). Scientists still don’t know exactly when or how the first humans evolved, but they’ve identified a few of the oldest ones.\r\n\r\nOne of the earliest known humans is Homo habilis, or “handy man,” who lived about 2.4 million to 1.4 million years ago in Eastern and Southern Africa. Others include Homo rudolfensis, who lived in Eastern Africa about 1.9 million to 1.8 million years ago (its name comes from its discovery in East Rudolph, Kenya); and Homo erectus, the “upright man” who ranged from Southern Africa all the way to modern-day China and Indonesia from about 1.89 million to 110,000 years ago.', 'Science', 'Published', '2023-08-26 10:38:18', '2023-08-26 23:42:40'),
(5, 'Title Book', 'Content Book', 'Cat Book', 'Trashed', '2023-08-26 10:38:32', '2023-08-26 23:44:46'),
(6, 'Title Here', 'Content Here', 'Cat Here', 'Draft', '2023-08-26 10:38:32', '2023-08-26 21:36:49'),
(7, 'Title Bad', 'Content Bad', 'Cat Trash', 'Trashed', '2023-08-26 10:38:32', '2023-08-26 23:44:42'),
(8, 'The Moon', 'The moon is not beautiful', 'Novel', 'Draft', '2023-08-26 13:15:03', '2023-08-26 21:10:03'),
(9, 'The Sun', 'The sun is hot', 'Comedy', 'Trashed', '2023-08-26 13:16:57', '2023-08-26 21:51:42'),
(10, 'The Stars', 'The stars are far away', 'Romance', 'Trashed', '2023-08-26 13:39:14', '2023-08-26 21:52:28'),
(12, 'coba', 'coba', 'coba', 'Draft', '2023-08-26 13:44:55', '2023-08-26 20:44:55'),
(15, 'stat', 'stat', 'stat', 'Trashed', '2023-08-26 13:48:39', '2023-08-26 21:53:13'),
(17, 'The Roman Empire', 'The Roman Empire at its territorial peak. Between the years 14 and 68 the heirs of Augustus succeeded him: Tiberius, Caligula, Claudius and Nero. This dynastic succession was interrupted when emperor Nero died and a civil war broke out in the year 68. Three emperors fought for the power and finally the war was won by Vespasian, part of the Flavian dynasty.\r\n\r\nThe Flavian dynasty was succeeded by the Antonines (96 – 193), a generic name given to Nerva, Trajan, Hadrian, Antoninus Pius, Marcus Aurelius and Commodus. These emperors had a very similar policy to the Flavians.\r\n\r\nThe accession of Septimius Severus (197 – 235) made him the first of the Imperial Severan Dynasty to rule (197 – 235). He was replaced by Caracalla, Macrinus, Elagabalus and Alexander Severus.\r\n\r\nThe absolute power of Rome, capital of the Empire, was weakened over time. Between 235 and 300 Rome’s only priority was to defend its borders from the continuous attacks by the Barbarians and from the Sasanians (from Persia). The pressure of these raids prompted the   army to assume power in 235. This era is known as the military anarchy and lasted about fifty years. The emperors of this time had one sole purpose: fighting the Empire’s enemies and securing the borders.', 'History', 'Published', '2023-08-26 15:35:10', '2023-08-26 23:39:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
