<?php
include "top.php"; 
include "dbx.php";
include "tabel.php";
$tab=5;
include "tab.php"; 
$qry = "SELECT COUNT(*) as total FROM posts where Status='Published' ";
$data = $db->query($qry);
$row = $data->fetch_assoc();
$totalItems = $row['total'];

$itemsPerPage = 1;
$totalPages = ceil($totalItems / $itemsPerPage);

$currentPage = isset($_GET['page']) ? $_GET['page'] : 1;

$offset = ($currentPage - 1) * $itemsPerPage;

$qry = "SELECT * FROM posts where Status='Published' LIMIT $offset, $itemsPerPage";
$data = $db->query($qry);

$n=0;

    $qry = "SELECT * FROM posts where Status='Published' LIMIT $offset, $itemsPerPage";
    $data = $db->query($qry);  
    while ($row = $data->fetch_assoc()) {  
        $n=$n+1;
        $judul= $row["Title"];
        $konten= $row["Content"];
        $kategori= $row["Category"];
    }    
    ?>
    
<div class="container">
        <div class="row">
        <div style="text-align: center; margin-top: 20px;">
            <?php
            echo "<ul class='pagination'>";
            for ($i = 1; $i <= $totalPages; $i++) {
            echo "<li><a href='?page=$i'>$i</a></li>";
            }
            echo "</ul>"; 
            ?> 
            </div>
            <div class="col-md-15">
                <h1 class="text-center"><?php echo $judul; ?></h1>
                <h4 class="text-center">Category: <?php echo $kategori; ?></h4>
    
            </div>
        </br>
            <h4 class="text-center"><?php echo $konten; ?></h4>
    
            
        </div>
</div>