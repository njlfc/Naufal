<?php
include "top.php"; 
include "dbx.php";
include "tabel.php";

$qry = "SELECT * FROM posts where Id='".$_GET['id']."'";
$data = $db->query($qry);
$row = $data->fetch_assoc();
?>

<form method="post" name="frm" action="edit_action.php">
  
  <div class="container">
        <div class="row">
        <div class="col-md-15">
                <h1 class="text-center">Edit Article</h1>
            </div>
            <div class="col-md-2 col-md-offset-1">
    
  <table class="table table-bordered" id="csstab1">

    <tbody> 
      <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" size="20" readonly> 
  <tr>
    <td valign="top" size="20" ><strong> Title</strong></td>
    <td><input type="text" name="title" size="50" placeholder="Article Title"  value="<?php echo $row['Title']; ?>"/></td>
  </tr>
  
  <tr>
  <td ><strong>Content</strong></td>
    <td>
    <textarea input type="text" cols="100px" rows="2" name="content" placeholder="Article Content" value="<?php echo $row['Content']; ?>"><?php echo $row['Content']?></textarea >
    </td>
    </tr>
  <tr>
    <td   ><strong>Category</strong></td>
    <td ><input type="text" name="category" size="50" placeholder="Article Category" value="<?php echo $row['Category']; ?>" /></td>
  </tr>
  <tr>
    <td colspan="2"><input type="submit" name="add" class="btn bg-success" value="Publish"> <input type="submit" name="add" class="btn bg-info" value="Draft"></input></td>
  </tr>
  </tbody>  
</table>
</div>
</div>
</div>
</form>