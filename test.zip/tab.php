<div class="container">
        <div class="row">
            <div class="col-md-12">
            <?php if($tab==1) echo '<h1 class="text-center">All Post</h1>';?>
            <?php if($tab==2) echo '<h1 class="text-center">Published</h1>';?>
            <?php if($tab==3) echo '<h1 class="text-center">Drafts</h1>';?>
            <?php if($tab==4) echo '<h1 class="text-center">Trashed</h1>';?>   
            <?php if($tab==6) echo '<h1 class="text-center">Add New Post</h1>';?>
            <?php if($tab==5) echo '<h1 class="text-center">Preview Post</h1>';?>    

            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <ul class="nav nav-pills nav-justified">
                    <li class="<?php if($tab==1) echo 'active';?> " ><a href="index.php">All Post</a></li> 
                    <li class="<?php if($tab==2) echo 'active';?> " ><a href="published.php">Published</a></li>
                    <li class="<?php if($tab==3) echo 'active';?> " ><a href="drafts.php">Drafts</a></li>
                    <li class="<?php if($tab==4) echo 'active';?> " > <a href="trashed.php">Trashed</a></li>
                    <li class="<?php if($tab==5) echo 'active';?> " > <a href="preview.php">Preview</a></li>
                    <li class="<?php if($tab==6) echo 'active';?> " ><a href="add.php">Add New +</a></li>
                </ul>
            </div>
        </div>
    </div>
</br>