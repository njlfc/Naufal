<style> 

#csstab1 {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    font-size:15px;
    border-collapse: collapse;
 
	background-color:#ffffff;
}

#csstab1 td, #csstab1 th {
    border: 1px solid #ccc;
    padding: 6px;
}

#csstab1 th {
    padding-top: 6px;
    padding-bottom: 6px;
    text-align: center;
    background-color: #616D7E ;
    color: white;
}
</style>