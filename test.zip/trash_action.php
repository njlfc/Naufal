<?php
include "top.php"; 
include "dbx.php";
include "tabel.php";

$url = "url=trashed.php";
if ($_GET['met']=='draft'){
    $url = "url=drafts.php";
}
if ($_GET['met']=='published'){
    $url = "url=published.php";
}
if ($_GET['met']=='all'){
    $url = "url=index.php";
}
$qry ="UPDATE posts SET Status='Trashed' where Id='".$_GET['id']."' " ;

mysqli_query($db, $qry);
?>
<meta http-equiv="refresh" content="1;  <?php echo $url; ?>  ">
<center>
	<h2>LOADING.........</h2>
</center>