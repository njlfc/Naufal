<?php
include "top.php"; 
include "dbx.php";
include "tabel.php";

if ( $_POST['add'] == 'Publish'){
    $stat='Published';
}else {
    $stat='Draft';
}

$qry ="INSERT INTO posts (Title, Content, Category, Status) VALUES ('".$_POST['title']."', '".$_POST['content']."', '".$_POST['category']."', '".$stat."')";
mysqli_query($db, $qry);
?>
<meta http-equiv="refresh" content="1; url=index.php">
<center>
	<h2>LOADING.........</h2>
</center>
