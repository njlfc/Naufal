<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "article";


$db = new mysqli($servername, $username, $password, $dbname);

if ($db->connect_error) {
    die("error" . $db->connect_error);
}


?>